package com.deloitte.employee;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import lombok.Data;

@Data
@Component("unit1")

@PropertySource("employee.properties")
public class BusinessUnit {
	@Value("${buid}")	
	int buId;
	@Value("${buname}")
		String buName;
	}
