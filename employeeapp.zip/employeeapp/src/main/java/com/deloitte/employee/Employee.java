package com.deloitte.employee;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import lombok.Data;

@Data

@Scope("prototype")

public class Employee implements InitializingBean,DisposableBean{
	@Value("${empid}")
	int employeeId;
	@Value("${empname}")
	String employeeName;
	@Autowired
	@Qualifier("unit1")
	BusinessUnit businessunit;
	
	public Employee() {
		System.out.println("Employee object created");
	}

	public void afterPropertiesSet() throws Exception {
	
		System.out.println("employee bean initialized");
		
	}

	public void destroy() throws Exception {
		System.out.println();
		
	}
	
	
	
	
	

}
