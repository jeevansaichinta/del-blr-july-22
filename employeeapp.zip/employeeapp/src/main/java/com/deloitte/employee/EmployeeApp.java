package com.deloitte.employee;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class EmployeeApp {

	public static void main(String[] args) {
		
		ApplicationContext context = new AnnotationConfigApplicationContext(EmployeeConfig.class);		
		// BusinessUnit bu = context.getBean(BusinessUnit.class);
		Employee emp = context.getBean(Employee.class);
		Employee emp1 = context.getBean(Employee.class);
		Employee emp2 = context.getBean(Employee.class);
		Employee emp3 = context.getBean(Employee.class);
		emp3.setEmployeeName("john");
		System.out.println(emp);
		System.out.println(emp1);
		System.out.println(emp2);
		System.out.println(emp3);

	}

}
