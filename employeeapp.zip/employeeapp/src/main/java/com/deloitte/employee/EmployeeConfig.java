package com.deloitte.employee;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.Scope;

@Configuration
@ComponentScan
@PropertySource("employee.properties")
public class EmployeeConfig {
	
	@Bean("unit2")
	public BusinessUnit getBu() {
		BusinessUnit bu = new BusinessUnit();
		//bu.setBuId(1001);
		//bu.setBuName("Suraj");
		return bu;
	}
	
	@Bean
	@Scope("singleton")
	@Lazy
	public Employee getEmp() {
		Employee emp = new Employee();
		//emp.setEmployeeName();
		//emp.setEmployeeId();
		//emp.setBusinessunit(getBu());
		return emp;
	}
	
	
	

}
